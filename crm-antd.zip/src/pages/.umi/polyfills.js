import 'core-js';
import 'regenerator-runtime/runtime';

// Include this seperatly since it's not included in core-js
// ref: https://github.com/zloirock/core-js/issues/117
import '../../../node_modules/_url-polyfill@1.1.5@url-polyfill/url-polyfill.js';
