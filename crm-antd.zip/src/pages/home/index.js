import React from 'react';


import moment from 'moment';
import { Input, Tag, Select, Cascader} from 'antd';
import { connect } from 'dva';
import imgURL from './seek_img.jpg'
const styles = require('./index.less');
const { Search } = Input;
const { Option } = Select;
const { CheckableTag } = Tag;

const tagsEstablish = ['不限','1年内', '1-5年', '5-10年', '15年以上','自定义'];
const tagsManagement = ['不限','在业/存续', '迁入/迁出', '吊销/撤销', '注销', '其他'];
const tagsRegister = ['不限', '100万以内', '100-200万', '200-500万', '500-1000万', '1000万以上', '其他'];
const tagsEnterprise = ['不限', '企业', '个体工商户', '其他'];
const options = [
  {
    value: 'zhejiang',
    label: 'Zhejiang',
    children: [
      {
        value: 'hangzhou',
        label: 'Hanzhou',
      },
    ],
  },
  {
    value: 'jiangsu',
    label: 'Jiangsu',
    children: [
      {
        value: 'nanjing',
        label: 'Nanjing',
      },
    ],
  },
];
@connect(({ Seek }) => ({
  Seek
}))
export default class Seek extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      keyWord:'',
      industry:'',
      region:'',
      selectedTags: ['不限'],
      selectedTags1: ['不限'],
      selectedTags2: ['不限'],
      selectedTags3: ['不限'],
      seekPhone:'',
      seekExtension:'',
      seekWebsite:'',
      seekKeep:'',
      seekRecruit:'',
      seekRelease:'',
    };
  }

  componentWillMount() {
    // window.addEventListener('message', function (e) {   // iframe跨域传值
    //   console.log(e.data);
    //   var data = JSON.parse(e.data);
    //   console.log(data);
    //   console.log("e-------------------------");
    //   // var data = JSON.parse(e.data);
    //   // if (data) {
    //   //   data.number = 16;

    //   //   // 处理后再发回domain1
    //   //   window.parent.postMessage(JSON.stringify(data), 'http://www.domain1.com');
    //   // }
    // }, false);
  }
  onChangeIndustry = (value) =>{
    const { industry } = this.state;
    console.log(value);
    console.log("v-------------------------1111");
    this.setState({ industry: value})
  }
  onChangeRegion = (value) =>{
    const { region } = this.state;
    console.log(value);
    console.log("v-------------------------1111");
    this.setState({ region: value })
  }
  handleChange(e,value) {
    console.log(`selected ${value}selected${e}`);
  }
  ipnutSearch = (value) => {
    console.log(value);
    console.log("v-------------------------");
  }
  searchChange = (e) => {
    console.log(e.target.value);
    console.log("value----------------");
    this.setState({
      keyWord: e.target.value,
    });
  }
  handleChangeEstablish(tag) {
    const { selectedTags } = this.state;
    this.setState({ selectedTags: tag });
  }
  handleChangeManagement(tag) {
    const { selectedTags1 } = this.state;
    this.setState({ selectedTags1: tag });
  }
  handleChangeRegister(tag) {
    const { selectedTags1 } = this.state;
    this.setState({ selectedTags2: tag });
  }
  handleChangeEnterprise(tag) {
    const { selectedTags1 } = this.state;
    this.setState({ selectedTags3: tag });
  }
  render() {
    const { selectedTags, selectedTags1, selectedTags2, selectedTags3 } = this.state;
    return (
      <div>
        <div className={styles.seek}>
          <Search
            placeholder="请输入客户名称"
            onSearch={this.ipnutSearch}
            onChange={this.searchChange}
            style={{ width: 316 }}
          />
        </div>
        <div className={styles.seek}>
          <div className={styles.seekList}>
            <div className={styles.seekHead}>地区/行业：</div>
            <div className={styles.seekTag}>
              <Cascader placeholder="请选择地区" options={options} onChange={this.onChangeRegion} changeOnSelect style={{marginRight:'15px',width:'120px'}}/>
              <Cascader placeholder="请选择行业" options={options} onChange={this.onChangeIndustry} changeOnSelect style={{ marginRight: '15px', width: '120px' }}/>
            </div>
          </div>
          <div className={styles.seekList}>
            <div className={styles.seekHead}>成立时间：</div>
            <div className={styles.seekTag}>
              {tagsEstablish.map(tag => (
                <CheckableTag
                  key={tag}
                  checked={selectedTags.indexOf(tag) > -1}
                  onChange={() => this.handleChangeEstablish(tag)}
                >
                  {tag}
                </CheckableTag>
              ))}
            </div>
          </div>
          <div className={styles.seekList}>
            <div className={styles.seekHead}>经营状态：</div>
            <div className={styles.seekTag}>
              {tagsManagement.map(tag => (
                <CheckableTag
                  key={tag}
                  checked={selectedTags1.indexOf(tag) > -1}
                  onChange={checked => this.handleChangeManagement(tag, checked)}
                >
                  {tag}
                </CheckableTag>
              ))}
            </div>
          </div>
          <div className={styles.seekList}>
            <div className={styles.seekHead}>注册资本：</div>
            <div className={styles.seekTag}>
              {tagsRegister.map(tag => (
                <CheckableTag
                  key={tag}
                  checked={selectedTags2.indexOf(tag) > -1}
                  onChange={checked => this.handleChangeRegister(tag, checked)}
                >
                  {tag}
                </CheckableTag>
              ))}
            </div>
          </div>
          <div className={styles.seekList}>
            <div className={styles.seekHead}>企业类型：</div>
            <div className={styles.seekTag}>
              {tagsEnterprise.map(tag => (
                <CheckableTag
                  key={tag}
                  checked={selectedTags3.indexOf(tag) > -1}
                  onChange={checked => this.handleChangeEnterprise(tag, checked)}
                >
                  {tag}
                </CheckableTag>
              ))}
            </div>
          </div>
          <div className={styles.seekList}>
            <div className={styles.seekHead}>高级筛选：</div>
            <div className={styles.seekTag}>
              <Select defaultValue="联系电话" onChange={e => this.handleChange(1, e)} style={{marginRight:'10px'}}>
                <Option value="联系电话">联系电话</Option>
                <Option value="有联系电话">有联系电话</Option>
                <Option value="无联系电话">无联系电话</Option>
              </Select>
              <Select defaultValue="推广情况" onChange={e => this.handleChange(2, e)} style={{ marginRight: '15px' }}>
                <Option value="推广情况">推广情况</Option>
                <Option value="有推广">有推广</Option>
                <Option value="无推广">无推广</Option>
              </Select>
              <Select defaultValue="网站域名" onChange={e => this.handleChange(3, e)} style={{ marginRight: '15px' }}>
                <Option value="网站域名">网站域名</Option>
                <Option value="有网站">有网站</Option>
                <Option value="无网站">无网站</Option>
              </Select>
              <Select defaultValue="网站备案时间" onChange={e => this.handleChange(4, e)} style={{ marginRight: '15px' }}>
                <Option value="d1">Jack</Option>
                <Option value="d2">Lucy</Option>
                <Option value="d3">yiminghe</Option>
              </Select>
              <Select defaultValue="招聘情况" onChange={e => this.handleChange(5, e)} style={{ marginRight: '15px' }}>
                <Option value="招聘情况">招聘情况</Option>
                <Option value="有招聘信息">有招聘信息</Option>
                <Option value="无招聘信息">无招聘信息</Option>
              </Select>
              <Select defaultValue="职位发布时间" onChange={e => this.handleChange(6, e)} style={{ marginRight: '15px' }}>
                <Option value="f1">Jack</Option>
                <Option value="f2">Lucy</Option>
              </Select>
            </div>
          </div>
        </div>
        <div>
          <div style={{textAlign:'center',padding:'20px'}}><img src={imgURL}></img></div>
          <div style={{ textAlign: 'center',fontSize:'17px'}}>暂无数据</div>
        </div>
      </div>
    );
  }
}
