import { getBasicFacts,getLivelyUser,getPayedCom } from '@/services/indexModels';

export default {
  namespace: 'indexModels',

  state: {
    basicFacts: {},
    livelyUser: {},
    companys: {},
  },

  effects: {
    *basicFacts({ payload }, { call, put }){
      const response = yield call(getBasicFacts,payload);
      yield put({
        type: 'saveBasicFacts',
        payload: response,
      });
    },
    *livelyUser({payload}, { call, put }) {
      // console.info("开始请求livelyUser",payload)
      const response = yield call(getLivelyUser,payload);
      yield put({
        type: 'saveLivelyUser',
        payload: response,
      });
    },
    *payedCom({payload}, { call, put }) {
      const response = yield call(getPayedCom,payload);
      yield put({
        type: 'savePayedCom',
        payload: response,
      });
    },
  },

  reducers: {
    saveBasicFacts(state, action) {
      return {
        ...state,
        basicFacts: action.payload||{},
      };
    },
    saveLivelyUser(state, action) {
      return {
        ...state,
        livelyUser: action.payload || {},
      };
    },
    savePayedCom(state, action) {
      return {
        ...state,
        companys: action.payload || {},
      };
    },
  },
};
