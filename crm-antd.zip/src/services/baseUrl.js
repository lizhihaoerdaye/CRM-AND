 export const baseUrl = 'http://192.168.36.81:8050';
//  export const baseUrl = 'http://192.168.36.81:8058';
// export const baseUrl = "http://10.168.254.163:8050"
// export const baseUrl = "https://server.qijiee.com"
