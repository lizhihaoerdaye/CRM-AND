import * as React from 'react';

export interface ILoginTabProps {
  key?: string;
  tab?: React.ReactNode;
}
export default class LoginTab extends React.Component<ILoginTabProps, any> {}
